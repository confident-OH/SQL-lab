package com.example.database.entity;

import java.util.Date;

public class IsolationLocation {
    private Integer id;
    private String locationName;
    private Integer capacity;

}
