package com.example.database.entity;

import java.util.Date;

public class Itinerary {
    private Integer id;
    private Integer pId;
    private Integer locId;
    private Date sTime;
    private Date eTime;
}
