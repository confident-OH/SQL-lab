package com.example.database.entity;

import java.util.Date;

public class IsolationRecord {
    private Integer id;
    private Integer pId;
    private Date sDate;
    private Date eDate;
    private Integer isolLocId;
    private Integer state;
}
