package com.example.database.entity;

import java.util.Date;

public class DiagnoseRecord {
    private Integer id;
    private Integer pId;
    private Date datetime;
    private Integer result;
}
