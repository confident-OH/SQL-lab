package com.example.database.service;

public interface UserService {
    void update(Integer id);
}
