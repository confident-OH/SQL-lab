## Datebase demo

> 项目主要有两个例子
> 
- 第一个是关于事务的使用（ [链接](https://github.com/nansanhao/database/blob/main/Spring%20boot%E4%BA%8B%E5%8A%A1demo.pptx)），

- 第二个是关于复杂查询（ [链接](https://github.com/nansanhao/database/blob/main/Spring%20boot%20%E4%BC%A0%E6%9F%93%E9%93%BEdemo.pptx)），这里查询的是新冠疫情的传染链，即A传染B，B可以传染C和D，C和D也可以传染其他人。

分别有相应的配套ppt作为讲解。

